from django.shortcuts import render

def gthtdjlxbr(request):
    return render(request, "main/gthtdjlxbr.html")

def about(request):
    return render(request, "main/about.html")
